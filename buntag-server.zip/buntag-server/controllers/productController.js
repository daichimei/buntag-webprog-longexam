const Product = require("../models/productModel");
const Category = require("../models/categoryModel");
const { HttpStatus } = require("../config/constants");

// Public — customers, suppliers, admins can all browse
exports.getProducts = async (req, res) => {
    try {
        //pagination
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        //filter
        const filter = {};
        if (req.query.category) {
        const category = await Category.findOne({ categoryName: req.query.category });
        if (!category) {
            return res.status(HttpStatus.NOT_FOUND).json({
            success: false,
            message: "Category not found"
            });
        }
        filter.category = category._id;
        }

        if (req.query.inStock === "true") {
        filter.stock = { $gt: 0 };
        }

        if (req.query.search) {
        filter.productName = { $regex: req.query.search, $options: "i" };
        }

        // sort
        let sort = {};
        if (req.query.sort) {
        const sortField = req.query.sort.startsWith("-")
            ? req.query.sort.substring(1)
            : req.query.sort;
        const sortOrder = req.query.sort.startsWith("-") ? -1 : 1;
        sort[sortField] = sortOrder;
        }

        const total = await Product.countDocuments(filter);

        const products = await Product.find(filter)
        .populate("category", "categoryName")
        .sort(sort)
        .skip(skip)
        .limit(limit);

        res.status(HttpStatus.OK).json({
        success: true,
        message: "Products retrieved successfully",
        count: products.length,
        pagination: {
            currentPage: page,
            limit,
            totalProducts: total,
            totalPages: Math.ceil(total / limit)
        },
        data: products
        });
    } catch (error) {
        res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: error.message
        });
    }
};

exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id).populate("category", "categoryName");

        if (!product) {
        return res.status(HttpStatus.NOT_FOUND).json({
            success: false,
            message: "Product not found"
        });
        }

        res.status(HttpStatus.OK).json({
        success: true,
        message: "Product retrieved successfully",
        data: product
        });
    } catch (error) {
        res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: error.message
        });
    }
};

exports.createProduct = async (req, res) => {
    try {
        const newProduct = new Product(req.body);
        const savedProduct = await newProduct.save();

        res.status(HttpStatus.CREATED).json({
        success: true,
        message: "Product created successfully",
        data: savedProduct
        });
    } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json({
        success: false,
        message: error.message
        });
    }
};

exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id).populate("category", "categoryName");

        if (!product) {
        return res.status(HttpStatus.NOT_FOUND).json({
            success: false,
            message: "Product not found"
        });
        }

        res.status(HttpStatus.OK).json({
        success: true,
        message: "Product retrieved successfully",
        data: product
        });
    } catch (error) {
        res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: error.message
        });
    }
};

// Supplier + Admin only
exports.createProduct = async (req, res) => {
    try {
        const newProduct = new Product({
        ...req.body,
        user: req.user.id, // supplier who owns this product
        });
        const savedProduct = await newProduct.save();

        res.status(HttpStatus.CREATED).json({
        success: true,
        message: "Product created successfully",
        data: savedProduct,
        });
    } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json({
        success: false,
        message: error.message,
        });
    }
};

// Supplier can only update their own products; admin can update any
exports.updateProduct = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
        return res.status(HttpStatus.NOT_FOUND).json({
            success: false,
            message: "Product not found",
        });
        }

        if (req.user.role === "supplier" && product.user.toString() !== req.user.id) {
        return res.status(HttpStatus.FORBIDDEN).json({
            success: false,
            message: "You can only update your own products",
        });
        }

        const updatedProduct = await Product.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true, runValidators: true }
        );

        res.status(HttpStatus.OK).json({
        success: true,
        message: "Product updated successfully",
        data: updatedProduct,
        });
    } catch (error) {
        res.status(HttpStatus.BAD_REQUEST).json({
        success: false,
        message: error.message,
        });
    }
};

// Same ownership rule for delete
exports.deleteProduct = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
        return res.status(HttpStatus.NOT_FOUND).json({
            success: false,
            message: "Product not found",
        });
        }

        if (req.user.role === "supplier" && product.user.toString() !== req.user.id) {
        return res.status(HttpStatus.FORBIDDEN).json({
            success: false,
            message: "You can only delete your own products",
        });
    }

    await Product.findByIdAndDelete(req.params.id);

    res.status(HttpStatus.OK).json({
        success: true,
        message: "Product deleted successfully",
        });
    } catch (error) {
        res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: error.message,
        });
    }
};