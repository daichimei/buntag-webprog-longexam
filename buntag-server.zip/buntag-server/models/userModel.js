const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    name: {
        type: String, required: true
    },
    email: {
        type: String, required: true, unique: true
    },
    password: {
        type: String, required: true
    },
    address: {
        type: String
    },
    profilePicture: {
        type: String
    },
    role: {
        type: String, enum: ["customer", "supplier", "admin"], default: "customer"
    },
    isActive: {
        type: Boolean, default: true
    },
}, {
    timestamps: true
});

module.exports = mongoose.model("User", userSchema);